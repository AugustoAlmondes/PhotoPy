from .linear import alargamento_contraste
from .linear import negativo
from .linear import logaritmica
from .linear import potencia
from .nonlinear import median
from .nonlinear import moda
from .nonlinear import maximum
from .nonlinear import minimum